$(document).ready(function() {
    // 注册表单提交事件
    $("#registrationForm").submit(function(event) {
        event.preventDefault();

        var regaccount = $("#account").val();
        var regpassword = $("#password0").val();
        var regpassword1 = $("#password1").val();

        // 发送注册信息到后端处理
        $.ajax({
            url: "/register",
            method: "POST",
            data: {
                account: regaccount,
                password: regpassword,
                password1: regpassword1
            },
            success: function(response) {
                if (regaccount === '')
                {
                  alert("请输入账号");
                }
                else if (regpassword === '')
                {
                  alert("请输入密码");
                }
                else if (regpassword1 === '')
                {
                  alert("请确认密码");
                }
                else if ((regpassword !== regpassword1) || (response === "notsimilar"))
                {
                  alert("两次密码输入不一致");
                }
                else if (response === "existence")
                {
                    alert("用户名已存在，请选择其他用户名！");
                }
                else if (response === "success") {
                    showSuccessMessage("注册成功，请登录");
                    var countdown = 3;
                    var countdownTimer = setInterval(function() {
                        countdown--;
                        if (countdown === 0)
                        {
                            clearInterval(countdownTimer);
                            window.location.href = "/signinorregister";
                        }
                        else {
                            updateCountdown(countdown);
                        }}, 1000);
                }
                else {
                    alert("注册失败，请重新注册");
                }
            },
            error: function() {
                alert("注册中出现问题，请刷新后重试.");
            }
        });
    });
});


function showSuccessMessage(message) {
    var successBox = document.getElementById("success-box");
    successBox.innerText = message;
    successBox.style.display = "block";
}

function updateCountdown(countdown) {
    var successBox = document.getElementById("success-box");
    successBox.innerText = countdown + " 秒后自动跳转";
}


const eye0 = document.getElementById('eye0');
const pwd0 = document.getElementById('password0');
var flag = 0;
eye0.onclick = function() {
    if (flag === 0) {
        pwd0.type = 'text';
        eye0.src = '/static/assets/img/eyeopen.png';
        flag = 1;
    } else {
        pwd0.type = 'password';
        eye0.src = '/static/assets/img/eyeclose.png';
        flag = 0;
    }
}

var eye1 = document.getElementById('eye1');
var pwd1 = document.getElementById('password1');
var flag1 = 0;
eye1.onclick = function() {
    if (flag1 === 0) {
        pwd1.type = 'text';
        eye1.src = '/static/assets/img/eyeopen.png';
        flag1 = 1;
    } else {
        pwd1.type = 'password';
        eye1.src = '/static/assets/img/eyeclose.png';
        flag1 = 0;
    }
}