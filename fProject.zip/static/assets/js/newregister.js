// 等待文档加载完成
document.addEventListener("DOMContentLoaded", function() {
    // 获取要渐变显示的元素
    const loginbox = document.querySelector(".login-box");

    // 将元素透明度设置为1（完全不透明），触发渐变效果
    loginbox.style.transition = "opacity 3s";
    loginbox.style.opacity = "1";
});

$(document).ready(function() {
    // 注册表单提交事件
    $("#signup__form").submit(function(event) {
        event.preventDefault();

        var signupEmail = $("#account").val();
        var signupPassword = $("#login-pass").val();
        var loader = document.getElementById("loader"); // 获取加载动画元素
        const loginbox = document.querySelector(".login-box");
        const mainContent1 = document.querySelector(".wrap");
        const mainContent = document.querySelectorAll(".wall2");

        // 发送登录信息到后端验证
        $.ajax({
            url: "/register",
            method: "POST",
            data: {
                account: signupEmail,
                password: signupPassword
            },
            success: function(response) {
                // 模拟登录过程，这里使用setTimeout
                loader.style.display = "flex"; // 显示加载动画

                setTimeout(function ()
                {
                    // 模拟登录成功后的操作
                    loader.style.display = "none"; // 隐藏加载动画
                    if (response === "success")
                    {
                        showSuccessMessage("注册成功,请登录。");
                        loginbox.style.transition = "opacity 3s";
                        loginbox.style.opacity = "0";
                        setTimeout(() => {
                            loginbox.style.display = "none";
                        }, 1500);
                        var bgImage = $("button[name='submit']").data("bg-image");
                        // 切换背景图像
                        // 停止动画
                        mainContent1.style.animation = "none";

                        // 遍历所有 .wall1 元素，并为它们设置新的背景图路径
                        mainContent.forEach((element) => {
                            element.style.backgroundImage = `url("../static/assets/img/${bgImage}")`;
                        });

                        // 在背景图像更改后，重新启动动画
                        mainContent1.style.animation = "move 20s linear infinite";
                        setTimeout(function ()
                        {
                            window.location.href = "/";
                        },5000)
                    }
                    else if (response === "existence")
                    {
                        showSuccessMessage("账户已存在，请重新注册。");
                    }
                    else if (response === "failure")
                    {
                        showSuccessMessage("注册失败，请重试！");
                    }
                }, 2000); // 模拟登录延迟2秒
            },
            error: function() {
                showSuccessMessage("注册中发生未知错误。");
            }
        });
    });
});

function showSuccessMessage(message) {
    var successBox = document.getElementById("success-box");
    successBox.style.display = "flex";
    successBox.innerText = message;
    setTimeout(function ()
    {
        successBox.style.display = "none";
    },2000)
}


/*=============== SHOW HIDDEN - PASSWORD ===============*/
const showHiddenPass = (loginPass, loginEye) =>{
   const input = document.getElementById(loginPass),
         iconEye = document.getElementById(loginEye)

   iconEye.addEventListener('click', () =>{
      // Change password to text
      if(input.type === 'password'){
         // Switch to text
         input.type = 'text'

         // Icon change
         iconEye.classList.add('ri-eye-line')
         iconEye.classList.remove('ri-eye-off-line')
      } else{
         // Change to password
         input.type = 'password'

         // Icon change
         iconEye.classList.remove('ri-eye-line')
         iconEye.classList.add('ri-eye-off-line')
      }
   })
}

showHiddenPass('login-pass','login-eye')
