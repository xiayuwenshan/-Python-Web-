const buttons = document.querySelectorAll('.button-container button');
const image = document.getElementById('image'); // 获取图片元素

buttons.forEach((button) => {
  button.addEventListener('click', () => {
    let imagePath;
    if (button.innerText === '经度') {
        imagePath = '../static/assets/image/经度_scatter_plot.png';
    } else if (button.innerText === '纬度') {
        imagePath = '../static/assets/image/纬度_scatter_plot.png';
    } else if (button.innerText === '高度角') {
        imagePath = '../static/assets/image/高度角_scatter_plot.png';
    } else if (button.innerText === '水平辐照') {
        imagePath = '../static/assets/image/水平辐照_scatter_plot.png';
    } else if (button.innerText === '晴空因子') {
        imagePath = '../static/assets/image/晴空因子_scatter_plot.png';
    } else if (button.innerText === '温度') {
        imagePath = '../static/assets/image/温度_scatter_plot.png';
    }  else if (button.innerText === '湿度') {
        imagePath = '../static/assets/image/湿度_scatter_plot.png';
    }  else if (button.innerText === '直射辐照') {
        imagePath = '../static/assets/image/直射辐照_scatter_plot.png';
    }  else if (button.innerText === '散射辐照') {
        imagePath = '../static/assets/image/散射辐照_scatter_plot.png';
    } 
    
    image.src = imagePath;
  });
});