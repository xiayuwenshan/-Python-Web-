const http = require('http');
const qs = require('querystring');

const server = http.createServer((req, res) => {
  if (req.method === 'POST' && req.url === '/login') {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk;
    });

    req.on('end', () => {
      const formData = qs.parse(body);
      const username = formData.account;
      const password = formData.password;

      if (username === 'admin' && password === 'password') {
        res.statusCode = 200;
        res.end('登录成功！欢迎，' + username);
      } else {
        res.statusCode = 401;
        res.end('用户名或密码错误，请重试！');
      }
    });
  } else {
    res.statusCode = 404;
    res.end('Not Found');
  }
});

server.listen(3000, () => {
  console.log('Server is listening on port 3000');
});