// 等待文档加载完成
document.addEventListener("DOMContentLoaded", function() {
    // 获取要渐变显示的元素
    const maincontent = document.querySelector(".main2");
    const iframecontent = document.querySelector("iframe");

    // 将元素透明度设置为1（完全不透明），触发渐变效果
    iframecontent.style.transition = "opacity 1.5s";
    iframecontent.style.opacity = "1";
    maincontent.style.transition = "opacity 3.5s";
    maincontent.style.opacity = "1";
});


// 获取所有cube
var cubeDom=document.getElementById("cube").children;
// 获取 所有function
var functionDom=document.getElementById("function").children;
for(let i=0;i<cubeDom.length;i++){
    // 循环 添加点击事件
    cubeDom[i].onclick=function(){
        //  设置所有div 隐藏
        for(let j=0; j<functionDom.length; j++){
            functionDom[j].style.transition="all 3.5s ease";
            functionDom[j].style.opacity="0";
            functionDom[j].style.display="none";
        }
        // 当前点击 li 对应的 div 显示
        if(i>3){
            functionDom[i-3].style.transition="all 3.5s ease";
            functionDom[i-3].style.opacity="1";
            functionDom[i-3].style.display="flex";
        }
        else{
            functionDom[i].style.transition="all 3.5s ease";
            functionDom[i].style.opacity="1";
            functionDom[i].style.display="flex";
        }
    }
}

// 获取音频元素
const audioPlayer = document.querySelector('.radio audio');
const buttons = document.querySelectorAll('.button-container button');
const image = document.getElementById('image'); // 获取图片元素

buttons.forEach((button) => {
  button.addEventListener('click', () => {
    let imagePath;
    if (button.innerText === '经度') {
        imagePath = '../static/assets/image/经度_scatter_plot.png';
    } else if (button.innerText === '纬度') {
        imagePath = '../static/assets/image/纬度_scatter_plot.png';
    } else if (button.innerText === '高度角') {
        imagePath = '../static/assets/image/高度角_scatter_plot.png';
    } else if (button.innerText === '水平辐照') {
        imagePath = '../static/assets/image/水平辐照_scatter_plot.png';
    } else if (button.innerText === '晴空因子') {
        imagePath = '../static/assets/image/晴空因子_scatter_plot.png';
    } else if (button.innerText === '温度') {
        imagePath = '../static/assets/image/温度_scatter_plot.png';
    }  else if (button.innerText === '湿度') {
        imagePath = '../static/assets/image/湿度_scatter_plot.png';
    }  else if (button.innerText === '直射辐照') {
        imagePath = '../static/assets/image/直射辐照_scatter_plot.png';
    }  else if (button.innerText === '散射辐照') {
        imagePath = '../static/assets/image/散射辐照_scatter_plot.png';
    }
    image.src = imagePath;
  });
});


// 获取按钮元素
const sendRequestButton = document.getElementById('sendRequestButton');
const messagesArea = document.getElementById('messages-area');
const changeback = document.querySelector(".overlay");
const loader = document.querySelector(".loader");
// 添加点击事件监听器
sendRequestButton.addEventListener('click', function() {
    // 发送请求到服务器
    changeback.style.display = "flex";
    loader.style.display = "flex";
    showSuccessMessage("AI助手正在分析中，请耐心听完她的回答……",2000);
    fetch('/aianalyse', {
        method: 'POST', // 请求方法
    })
    .then(response => {
        if (!response.ok) {
            showSuccessMessage("无法连接！");
        }
        return response.json();
    })
    .then(data => {
        if (data.messages === undefined) {
            // 服务器返回的数据为空
            showSuccessMessage("请重新解析");
            changeback.style.display = "none";
            loader.style.display = "none";
        }
        else {
            showSuccessMessage("解析结果已出。")
            changeback.style.display = "none";
            loader.style.display = "none";
            messagesArea.innerHTML = '';
            data.messages = data.messages.split('\n').filter(line => line.trim() !== '');
            // 将接收到的消息添加到消息区域
            data.messages.forEach((message, index) => {
                const newMessage = document.createElement('div');
                newMessage.classList.add('message');
                newMessage.style.height="auto";
                //newMessage.textContent = message;
                // 设置每个消息元素的 id
                newMessage.id = `message${index + 1}`;
                if(newMessage.id > '6'){
                    if(newMessage.style.background==="#343541"){
                        newMessage.style.background="#2E2F3A";
                    }else {
                        newMessage.style.background="#343541";
                    }
                }
                messagesArea.appendChild(newMessage);

                let charIndex = 0;
                const textInterval = setInterval(function () {
                    if (charIndex < message.length) {
                        newMessage.textContent += message[charIndex];
                        charIndex++;
                    } else {
                        clearInterval(textInterval);
                    }
                }, 100); // 控制字符显示的速度，单位是毫秒
                //audioPlayer.play();
            });
        }
    })
    .catch(error => {
        // 处理错误
        showSuccessMessage("发生未知错误，请刷新重试！");
        changeback.style.display = "none";
        loader.style.display = "none";
    });
});


const messageInput = document.getElementById('message-input');
const sendButton = document.getElementById('send-button');
// 添加点击事件监听器
sendButton.addEventListener('click', function() {
    // 发送请求到服务器
    changeback.style.display = "flex";
    loader.style.display = "flex";
    showSuccessMessage("AI助手正在回答中，请耐心听完……",2000);
    const messageText = messageInput.value;
    fetch('/aimessageanalyse', {
        method: 'POST', // 请求方法
        headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ message: messageText }),
    })
    .then(response => {
        if (!response.ok) {
            showSuccessMessage("无法连接！");
        }
        return response.json();
    })
    .then(data => {
        if (data.messages === undefined) {
            // 服务器返回的数据为空
            showSuccessMessage("请重新传输");
            changeback.style.display = "none";
            loader.style.display = "none";
        }
        else {
            showSuccessMessage("回答已出。")
            changeback.style.display = "none";
            loader.style.display = "none";
            //messagesArea.innerHTML = '';
            data.messages = data.messages.split('\n').filter(line => line.trim() !== '');
            // 将接收到的消息添加到消息区域
            data.messages.forEach((message, index) => {
                const newMessage = document.createElement('div');
                newMessage.classList.add('message');
                newMessage.style.height="auto";
                //newMessage.textContent = message;
                // 设置每个消息元素的 id
                newMessage.id = `message${index + 1}`;
                if(newMessage.id > '6'){
                    if(newMessage.style.background==="#343541"){
                        newMessage.style.background="#2E2F3A";
                    }else {
                        newMessage.style.background="#343541";
                    }
                }
                messagesArea.appendChild(newMessage);
                let charIndex = 0;
                const textInterval = setInterval(function () {
                    if (charIndex < message.length) {
                        newMessage.textContent += message[charIndex];
                        charIndex++;
                    } else {
                        clearInterval(textInterval);
                    }
                }, 100); // 控制字符显示的速度，单位是毫秒
                messageInput.value = '';
                //audioPlayer.play();
            });
        }
    })
    .catch(error => {
        // 处理错误
        showSuccessMessage("发生未知错误，请刷新重试！");
        changeback.style.display = "none";
        loader.style.display = "none";
    });
});


// 获取播放按钮和暂停按钮
const playButton = document.querySelector('.play-btn');
const pauseButton = document.querySelector('.pause-btn');

// 添加点击事件监听器来播放音频
playButton.addEventListener('click', function() {
    if (audioPlayer.paused) {
    audioPlayer.play(); // 如果音频暂停，点击后播放
    }
});

// 添加点击事件监听器来暂停音频
pauseButton.addEventListener('click', function() {
    if (!audioPlayer.paused) {
    audioPlayer.pause(); // 如果音频正在播放，点击后暂停
    }
});


function showSuccessMessage(message,time=1500) {
    var successBox = document.getElementById("success-box");
    successBox.style.display = "flex";
    successBox.innerText = message;
    if(time === 1500){
        setTimeout(() => {
            successBox.style.display = "none";
            }, time);
    }
}