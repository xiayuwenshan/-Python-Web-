// 获取链接元素
const registerLinks = document.querySelectorAll(".login__register a");

// 获取页面内容和背景元素
const loginbox = document.querySelector(".login-box");
const overlay = document.querySelector(".overlay");
const mainContent1 = document.querySelector(".wrap");
const mainContent = document.querySelectorAll(".wall1");

// 添加链接点击事件监听器
registerLinks.forEach((link) => {
    link.addEventListener("click", (event) => {
        // 阻止默认链接跳转行为
        event.preventDefault();

        loginbox.style.transition = "opacity 1s";
        loginbox.style.opacity = "0";
        setTimeout(() => {
            loginbox.style.display = "none";
        }, 1500);
        overlay.style.transition = "opacity 1s";
        overlay.style.opacity = "0";
        setTimeout(() => {
            overlay.style.display = "none";
        }, 1500);

        // 获取目标页面的背景图像文件名
        const bgImage = link.getAttribute("data-bg-image");

        // 切换背景图像
        // 停止动画
        mainContent1.style.animation = "none";

        // 遍历所有 .wall1 元素，并为它们设置新的背景图路径
        mainContent.forEach((element) => {
            element.style.backgroundImage = `url("../static/assets/img/${bgImage}")`;
        });

        // 在背景图像更改后，重新启动动画
        mainContent1.style.animation = "move 20s linear infinite";

        // 获取链接的目标URL
        const targetURL = link.getAttribute("href");

        // 在一定时间后跳转到目标URL
        setTimeout(() => {
            window.location.href = targetURL;
        }, 5000); // 这里的1000表示1秒，你可以根据需要调整延迟时间
    });
});


// 获取链接元素
const loginLinks = document.querySelectorAll(".register__login a");
const mainContent2 = document.querySelectorAll(".wall2");
// 添加链接点击事件监听器
loginLinks.forEach((link) => {
    link.addEventListener("click", (event) => {
        // 阻止默认链接跳转行为
        event.preventDefault();

        loginbox.style.transition = "opacity 1s";
        loginbox.style.opacity = "0";
        setTimeout(() => {
            loginbox.style.display = "none";
        }, 1500);
        // 获取目标页面的背景图像文件名
        const bgImage = link.getAttribute("data-bg-image");

        // 切换背景图像
        // 停止动画
        mainContent1.style.animation = "none";

        // 遍历所有 .wall1 元素，并为它们设置新的背景图路径
        mainContent2.forEach((element) => {
            element.style.backgroundImage = `url("../static/assets/img/${bgImage}")`;
        });

        // 在背景图像更改后，重新启动动画
        mainContent1.style.animation = "move 20s linear infinite";

        // 获取链接的目标URL
        const targetURL = link.getAttribute("href");

        // 在一定时间后跳转到目标URL
        setTimeout(() => {
            window.location.href = targetURL;
        }, 5000); // 这里的1000表示1秒，你可以根据需要调整延迟时间
    });
});

const dataanalyse = document.querySelectorAll(".data_analyse a");
const changemain = document.querySelector(".main");
const changeoverlay = document.querySelector(".overlay");
const changeiframe2 = document.getElementById('iframe2');
// 添加链接点击事件监听器
dataanalyse.forEach((link) => {
    link.addEventListener("click", (event) => {
        // 阻止默认链接跳转行为
        event.preventDefault();

        changemain.style.transition = "opacity 3.5s";
        changemain.style.opacity = "0";

        // 获取链接的目标URL
        const targetURL = link.getAttribute("href");

        // 在一定时间后跳转到目标URL
        setTimeout(() => {
            changeoverlay.style.display = "flex";
            changeoverlay.style.transition = "opacity 2.5s";
            changeoverlay.style.opacity = "1";
            window.location.href = targetURL;
            changeiframe2.style.transition = "opacity 1.5s";
            changeiframe2.style.opacity = "1";
        }, 1000); // 这里的1000表示1秒，你可以根据需要调整延迟时间
    });
});

const datapredict = document.querySelectorAll(".data_predict a");
const changemain2 = document.querySelector(".main2");
const changeoverlay2 = document.querySelector(".overlay");
const changeiframe = document.getElementById('iframe');
// 添加链接点击事件监听器
datapredict.forEach((link) => {
    link.addEventListener("click", (event) => {
        // 阻止默认链接跳转行为
        event.preventDefault();

        changemain2.style.transition = "opacity 3.5s";
        changemain2.style.opacity = "0";

        // 获取链接的目标URL
        const targetURL = link.getAttribute("href");

        // 在一定时间后跳转到目标URL
        setTimeout(() => {
            changeoverlay2.style.display = "flex";
            changeoverlay2.style.transition = "opacity 2.5s";
            changeoverlay2.style.opacity = "1";
            window.location.href = targetURL;
            changeiframe.style.transition = "opacity 1.5s";
            changeiframe.style.opacity = "1";
        }, 1000); // 这里的1000表示1秒，你可以根据需要调整延迟时间
    });
});