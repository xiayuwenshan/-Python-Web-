$(document).ready(function() {
    // 登录表单提交事件
    $("#loginForm").submit(function(event) {
        event.preventDefault();

        var loginUsername = $("#account").val();
        var loginPassword = $("#password").val();

        // 发送登录信息到后端验证
        $.ajax({
            url: "/login",
            method: "POST",
            data: {
                account: loginUsername,
                password: loginPassword
            },
            success: function(response) {
                if (loginUsername === '')
                {
                    alert("请输入账号");
                }
                else if (loginPassword === '')
                {
                    alert("请输入密码");
                }
                else if (response === "success")
                {
                    showSuccessMessage("登陆成功！");
                    var countdown = 3;
                    var countdownTimer = setInterval(function() {
                        countdown--;
                        if (countdown === 0)
                        {
                            clearInterval(countdownTimer);
                            window.location.href = "/operateinterface";
                        }
                        else {
                            updateCountdown(countdown);
                        }}, 1000);
                }
                else if (response === "failure")
                    {
                        alert("登录失败，账户不存在或密码错误！");
                    }
                },
            error: function() {
                alert("登录中发生未知错误。");
            }
        });
    });
});

function showSuccessMessage(message) {
    var successBox = document.getElementById("success-box");
    successBox.innerText = message;
    successBox.style.display = "block";
}

function updateCountdown(countdown) {
    var successBox = document.getElementById("success-box");
    successBox.innerText = countdown + " 秒后跳转";
}

var eye = document.getElementById('eye');
var pwd = document.getElementById('password');
var flag = 0;
eye.onclick = function() {
    if (flag === 0) {
        pwd.type = 'text';
        eye.src = '/static/assets/img/eyeopen.png';
        flag = 1;
    } else {
        pwd.type = 'password';
        eye.src = '/static/assets/img/eyeclose.png';
        flag = 0;
    }
}