function hasClass(element, clssname) {
    return element.className.match(new RegExp('(\\s|^)' + clssname + '(\\s|$)'))
}
function addClass(element, clssname) {
    if (!this.hasClass(element, clssname)) element.className += ' ' + clssname
}
function removeClass(element, clssname) {
    if (hasClass(element, clssname)) {
        var reg = new RegExp('(\\s|^)' + clssname + '(\\s|$)')
        element.className = element.className.replace(reg, ' ')
    }
}
function toggleClass(element, clssname) {
    if (hasClass(element, clssname)) {
        removeClass(element, clssname)
    } else {
        addClass(element, clssname)
    }
}

// 等待文档加载完成
document.addEventListener("DOMContentLoaded", function() {
    // 获取要渐变显示的元素
    const overay = document.querySelector(".overlay");

    // 将元素透明度设置为1（完全不透明），触发渐变效果
    overay.style.transition = "opacity 1.5s";
    overay.style.opacity = "1";
});

$(document).ready(function() {
    // 登录表单提交事件
    $("#login__form").submit(function(event) {
        event.preventDefault();

        var loginEmail = $("#account").val();
        var loginPassword = $("#login-pass").val();
        var loader = document.getElementById("loader"); // 获取加载动画元素
        var back = document.getElementById("white"); // 获取加载动画元素

        // 发送登录信息到后端验证
        $.ajax({
            url: "/login",
            method: "POST",
            data: {
                account: loginEmail,
                password: loginPassword
            },
            success: function(response) {
                // 模拟登录过程，这里使用setTimeout
                loader.style.display = "flex"; // 显示加载动画

                setTimeout(function ()
                {
                    // 模拟登录成功后的操作c
                    loader.style.display = "none"; // 隐藏加载动画
                    if (response === "success")
                    {
                        showSuccessMessage("登陆成功！");
                        setTimeout(function ()
                        {
                            back.style.display ="flex";
                        },1000)
                        setTimeout(function ()
                        {
                            window.location.href = "/predict";
                        },3000)
                    }
                    else if (response === "failure")
                    {
                        showSuccessMessage("登录失败，账户不存在或密码错误！");
                    }
                }, 2000); // 模拟登录延迟2秒
            },
            error: function() {
                showSuccessMessage("登录中发生未知错误。");
            }
        });
    });
});

function showSuccessMessage(message) {
    var successBox = document.getElementById("success-box");
    successBox.style.display = "flex";
    successBox.innerText = message;
    setTimeout(function ()
    {
        successBox.style.display = "none";
    },2000)
}


/*=============== SHOW HIDDEN - PASSWORD ===============*/
const showHiddenPass = (loginPass, loginEye) =>{
   const input = document.getElementById(loginPass),
         iconEye = document.getElementById(loginEye)

   iconEye.addEventListener('click', () =>{
      // Change password to text
      if(input.type === 'password'){
         // Switch to text
         input.type = 'text'

         // Icon change
         iconEye.classList.add('ri-eye-line')
         iconEye.classList.remove('ri-eye-off-line')
      } else{
         // Change to password
         input.type = 'password'

         // Icon change
         iconEye.classList.remove('ri-eye-line')
         iconEye.classList.add('ri-eye-off-line')
      }
   })
}

showHiddenPass('login-pass','login-eye')

var loginBox = document.getElementsByClassName('login-box')
var showBtn = document.getElementsByClassName('show-center-btn')
var hideBtn = document.getElementsByClassName('hide-login-btn')
showBtn[0].addEventListener('click', function() {
    toggleClass(loginBox[0], 'showed')
})
hideBtn[0].addEventListener('click', function() {
    toggleClass(loginBox[0], 'showed')
})