// 等待文档加载完成
document.addEventListener("DOMContentLoaded", function() {
    // 获取要渐变显示的元素
    const maincontent = document.querySelector(".main");
    const iframecontent = document.querySelector("iframe");

    // 将元素透明度设置为1（完全不透明），触发渐变效果
    iframecontent.style.transition = "opacity 1.5s";
    iframecontent.style.opacity = "1";
    maincontent.style.transition = "opacity 3.5s";
    maincontent.style.opacity = "1";
});

$(document).ready(function() {
    // 登录表单提交事件
    $("#dataform").submit(function(event) {
        event.preventDefault();

        var longitude = $("#longitude").val();
        var latitude = $("#latitude").val();
        var altitude = $("#altitude").val();
        var azimuth = $("#azimuth").val();
        var azimuthangle = $("#azimuthangle").val();
        var horizontalirradiation = $("#horizontalirradiation").val();
        var clearnessindex = $("#clearnessindex").val();
        var temperature = $("#temperature").val();
        var humidity = $("#humidity").val();

        const changeback = document.querySelector(".overlay");
        const loader = document.querySelector(".svg-frame");

        if (longitude === '' || latitude === '' || altitude === '' || azimuth === '' || azimuthangle === '' ||
                horizontalirradiation === '' || clearnessindex === ''|| temperature === '' || humidity === '')
                {
                    showSuccessMessage("数据输入不全，请补充！");
                }
        else{
            changeback.style.display = "flex";
            loader.style.display = "flex";
            showSuccessMessage("数据输入成功，正在预测，请稍后……");
            // 发送登录信息到后端验证
            $.ajax({
                url: "/datapredict",
                method: "POST",
                data: {
                    longitude : longitude,
                    latitude : latitude,
                    altitude : altitude,
                    azimuth : azimuth,
                    azimuthangle : azimuthangle,
                    horizontalirradiation : horizontalirradiation,
                    clearnessindex : clearnessindex,
                    temperature : temperature,
                    humidity : humidity,
                },
                success: function(response) {
                    if (response.directirradiation !== undefined && response.scatteredirradiation !== undefined && response.confident !== undefined)
                    {
                        var countdown = 5;
                        var countdownTimer = setInterval(function() {
                            countdown--;
                            if (countdown === 0)
                            {
                                clearInterval(countdownTimer);
                                showSuccessMessage("预测结果已出。");
                                changeback.style.display = "none";
                                loader.style.display = "none";
                                showdirectirradiation(response.directirradiation)
                                showscatteredirradiation(response.scatteredirradiation)
                                showconfidence(response.confident)
                            }
                            else {
                                updateCountdown(countdown);
                            }}, 1000);
                    }
                    else if (response === "failure")
                    {
                        showSuccessMessage("数据输入失败，请重新输入。");
                    }
                },
                error: function() {
                    showSuccessMessage("发生未知错误，请刷新重试。");
                }
            });
        }
    });
});


$(document).ready(function() {
    // 登录表单提交事件
    $("#outform").submit(function(event) {
        event.preventDefault();
        const changeback = document.querySelector(".overlay");
        const loader = document.querySelector(".svg-frame");
        $.ajax({
            url: "/save",
            method: "POST",
            success: function (response) {
                if (response === "wrong") {
                    showSuccessMessage("历史预测信息丢失，无法保存！")
                } else if (response === "success") {
                    changeback.style.display = "flex";
                    loader.style.display = "flex";
                    showSuccessMessage("正在保存数据……");
                    setTimeout(() => {
                        changeback.style.display = "none";
                        loader.style.display = "none";
                        showSuccessMessage("数据保存成功。")
                    }, 1000); // 这里的1000表示1秒，你可以根据需要调整延迟时间
                }
            },
            error: function () {
                showSuccessMessage("发生未知错误，请刷新重试。");
            }
        });
    });
});

function showSuccessMessage(message) {
    var successBox = document.getElementById("success-box");
    successBox.style.display = "flex";
    successBox.innerText = message;
    setTimeout(() => {
            successBox.style.display = "none";
    }, 1000); // 这里的1000表示1秒，你可以根据需要调整延迟时间
}

function updateCountdown(countdown) {
    var successBox = document.getElementById("success-box");
    successBox.style.display = "flex";
    successBox.innerText = countdown + " 秒后得出结果";
}

function showdirectirradiation(directirradiation) {
    var resultBox = document.getElementById("directirradiation");
    resultBox.innerText = directirradiation;
    resultBox.style.display = "block";
}

function showscatteredirradiation(scatteredirradiation) {
    var resultBox = document.getElementById("scatteredirradiation");
    resultBox.innerText = scatteredirradiation;
    resultBox.style.display = "block";
}

function showconfidence(confident) {
    var resultBox = document.getElementById("confidence");
    resultBox.innerText = confident;
    resultBox.style.display = "block";
}
