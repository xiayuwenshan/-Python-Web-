import json
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.model_selection import train_test_split
from torch.optim.lr_scheduler import StepLR

# 1. 读取 JSON 文件并准备数据
with open('cleaned_data.json', 'r') as json_file:
    data = json.load(json_file)

# 提取所需的特征和标签
features = []
labels = []

for item in data['data']:
    # 提取第3、4、5、8、9、10和11号元素，并除以1000进行归一化
    feature = [item[i]  for i in [2, 3, 4, 7, 8, 9, 10]]
    features.append(feature)
    label1 = item[11] / 500
    # 提取第12列的元素，并除以760
    label2 = item[12] / 800
    # 将这两个标签添加到标签列表中
    label = [label1, label2]
    labels.append(label)

# 转换为 PyTorch 张量
features = torch.tensor(features, dtype=torch.float32)
labels = torch.tensor(labels, dtype=torch.float32)
print(features[9])
print(labels[9][0]*415.8, labels[9][1]*760.0)

# 2. 拆分数据集
X_train, X_temp, y_train, y_temp = train_test_split(features, labels, test_size=0.2, random_state=42)
X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=0.67, random_state=42)

# 转换为 PyTorch 的 Dataset 和 DataLoader
train_dataset = TensorDataset(X_train, y_train)
train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True)

val_dataset = TensorDataset(X_val, y_val)
val_loader = DataLoader(val_dataset, batch_size=64)

# 3. 定义神经网络模型
class NeuralNetwork(nn.Module):
    def __init__(self, dropout_prob=0.45, weight_decay=1e-5):
        super(NeuralNetwork, self).__init__()
        self.fc1 = nn.Linear(7, 128)  # 输入特征维度为 7，输出维度为 128
        self.fc2 = nn.Linear(128, 64)  # 隐藏层1维度为 64
        #self.fc3 = nn.Linear(64, 64)  # 隐藏层2维度为 64
        self.fc4 = nn.Linear(64, 2)  # 输出维度为 2
        self.dropout = nn.Dropout(p=dropout_prob)  # 添加 dropout 层
        self.tanh = nn.Tanh()
        self.relu = nn.LeakyReLU()
        self.sig = nn.Sigmoid()
        self.l2_reg = weight_decay  # L2 正则化的权重衰减系数

    def forward(self, x):
        x = self.tanh(self.fc1(x))
        x = self.relu(self.fc2(x))
        x = self.dropout(x)
        #x = self.relu(self.fc3(x))
        x = self.sig(self.fc4(x))  # 输出层不应使用激活函数
        #x = self.fc4(x)  # 输出层不应使用激活函数
        return x

# 4. 定义损失函数和优化器
model = NeuralNetwork()
criterion = nn.MSELoss()  # 使用均方误差损失
optimizer = optim.Adam(model.parameters(), lr=0.001, weight_decay=model.l2_reg)  # Adam 优化器

# 添加学习率衰减器
lr_scheduler = StepLR(optimizer, step_size=400, gamma=0.5)

# 5. 训练神经网络，并记录损失变化
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)
num_epochs = 4000
best_val_loss = float('inf')
best_model_path = 'best_model.pth'

# 设置检查点保存路径
checkpoint_path = 'checkpoint_model.pth'
checkpoint_interval = num_epochs // 10  # 每十分之一的进度保存一次检查点
log_interval = 20  # 每20轮输出一次损失和学习率

def train(num_epochs, best_val_loss, best_model_path, device):
    for epoch in range(num_epochs):
        model.train()
        train_loss = 0.0

        for batch_idx, (inputs, targets) in enumerate(train_loader):
            inputs, targets = inputs.to(device), targets.to(device)
            optimizer.zero_grad()
            outputs = model(inputs)
            # outputs = outputs * 1000
            # targets = targets * 1000
            loss = criterion(outputs, targets)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()

        train_loss /= len(train_loader)

        # 验证模型
        model.eval()
        val_loss = 0.0

        with torch.no_grad():
            for inputs, targets in val_loader:
                inputs, targets = inputs.to(device), targets.to(device)
                outputs = model(inputs)
                # outputs = outputs * 1000
                # targets = targets * 1000
                loss = criterion(outputs, targets)
                val_loss += loss.item()

        val_loss /= len(val_loader)

        # 打印训练loss、验证loss、学习率、当前轮数
        if (epoch + 1) % log_interval == 0:
            print(f"Epoch [{epoch + 1}/{num_epochs}] Train Loss: {train_loss:.6f} Val Loss: {val_loss:.6f} Learning Rate: {lr_scheduler.get_lr()[0]}")

        # 保存最优模型
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            torch.save(model.state_dict(), best_model_path)

        # 学习率衰减
        lr_scheduler.step()

        # 每十分之一的进度保存一次检查点
        if (epoch + 1) % checkpoint_interval == 0:
            torch.save({
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'loss': val_loss
            }, checkpoint_path)

#train(num_epochs, best_val_loss, best_model_path, device)

# 6. 加载最优模型
model.load_state_dict(torch.load(best_model_path))


# 7. 编写测试函数以评估模型性能
def test_model(model, test_loader):
    model.eval()
    correct_predictions = 0
    total_samples = 0

    with torch.no_grad():
        for inputs, targets in test_loader:
            targets[0] *= 500
            targets[1] *= 800
            inputs, targets = inputs.to(device), targets.to(device)
            outputs = model(inputs)
            outputs[0] *= 500
            outputs[1] *= 800

            # 计算预测与真实值之间的误差
            errors = torch.abs(outputs - targets)
            #print(errors)

            # 判定误差小于0.1的预测为正确
            num_correct = torch.sum(errors < 0.5).item()
            #num_correct = torch.sum((1-errors)/targets).item()
            #print((1-errors)/targets)


            correct_predictions += num_correct
            total_samples += (inputs.size(0))*2
            #print(total_samples)

    accuracy = correct_predictions / total_samples
    return accuracy


# 转换测试集为 DataLoader
test_dataset = TensorDataset(X_test, y_test)
test_loader = DataLoader(test_dataset, batch_size=64)

# 测试模型并打印正确率
test_accuracy = test_model(model, test_loader)
print(f"Test Accuracy: {test_accuracy * 100:.2f}%")


def my_test(model):
    model.eval()

    # 提示用户输入特征值
    print("请输入小列表的3，4，5，8，9，10，11号的数据（以,分隔）:")
    input_str = input()
    input_list = [float(x) for x in input_str.split(",")]

    # 将用户输入的特征转换为张量
    input_tensor = torch.tensor(input_list, dtype=torch.float32).to(device)

    # 使用神经网络进行预测
    with torch.no_grad():
        prediction = model(input_tensor)
        prediction[0] *= 500
        prediction[1] *= 800

    print(f"神经网络的预测结果为：{prediction[0]:.2f}（小列表12号）, {prediction[1]:.2f}（小列表13号）")

# 调用 my_test 函数进行测试
my_test(model)

