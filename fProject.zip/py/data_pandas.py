import pandas as pd
import matplotlib.pyplot as plt
import json
from pylab import mpl

mpl.rcParams['font.sans-serif'] = ['STZhongsong']  # 指定默认字体：解决plot不能显示中文问题
mpl.rcParams['axes.unicode_minus'] = False  # 解决保存图像是负号'-'显示为方块的问题

def main():
    # 读取JSON文件
    with open('cleaned_data.json', 'r') as f:
        data_dict = json.load(f)

    # 将数据分为两部分，data1包含从第一个到倒数第二个数据，data2包含最后一个数据
    data = data_dict['data']
    data1 = data[:-1]
    data2 = [data[-1]]

    # 将数据转换为DataFrame
    columns = ['date_1', 'Time', '经度', '纬度', '高度角', '方位角', '转角', '水平辐照', '晴空因子', '温度', '湿度', '直射辐照', '散射辐照']
    df1 = pd.DataFrame(data1, columns=columns)
    df2 = pd.DataFrame(data2, columns=columns)

    # 选择要绘制的标签
    selected_columns = ['经度', '纬度', '高度角', '水平辐照', '晴空因子', '温度', '湿度', '直射辐照', '散射辐照']

    # 定义颜色列表
    colors = ['blue', 'green', 'red', 'purple', 'orange', 'brown', 'pink', 'gray', 'cyan']

    # 遍历每个标签并绘制散点图
    for idx, column in enumerate(selected_columns):
        plt.figure(figsize=(12, 8))

        # 绘制data1的散点图
        plt.scatter(range(1, len(df1) + 1), df1[column], label=column, color=colors[idx], marker='o', alpha=0.7)

        # 绘制data2的散点图，使用黑色和更大的点
        plt.scatter([len(df1) + 1], df2[column], label=column + ' (Predict Data)', color='black', marker='o', s=100)

        plt.xlabel('数据点序号')
        plt.ylabel(column)
        plt.title(column)
        plt.legend()

        # 保存图像文件，使用标签名字作为文件名
        plt.savefig(f'static/assets/image/{column}_scatter_plot.png')

        # 显示图形
        #plt.show()
