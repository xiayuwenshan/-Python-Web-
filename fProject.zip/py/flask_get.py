import requests

# 指定Flask应用的地址和端口
url = 'http://127.0.0.1:5000/predict'

# 准备要发送的7个数据，以逗号分隔
data = '14.4545,-53.02126,-40.26,33.9,0.096,13.8,0.636'
#data = '3.50807,-61.50503,-7.11,6.1,0.067,9.8,0.795'

# 发送GET请求
response = requests.post(f'{url}?data={data}')

# 检查响应状态码
if response.status_code == 200:
    print('GET请求成功！')
    # 获取预测结果
    prediction = response.text
    print(f'预测结果: {prediction}')
else:
    print('GET请求失败！')

# 你可以根据需要进一步处理预测结果
