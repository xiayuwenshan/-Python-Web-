import os
import edge_tts
import asyncio
from tqdm import tqdm

edge_tts_list = ['zh-CN-XiaoxiaoNeural','zh-CN-XiaoyiNeural','zh-CN-YunjianNeural','zh-CN-YunxiNeural','zh-CN-YunxiaNeural','zh-CN-YunyangNeural','zh-CN-liaoning-XiaobeiNeural','zh-CN-shaanxi-XiaoniNeural']

async def process_text_file(file_path, output_folder):
    # 读取txt文件的内容
    with open(file_path, 'rb') as f:
        data = f.read()
        text = data.decode('utf-8')

    # 创建输出文件名
    file_name = os.path.basename(file_path)
    output_path = os.path.join(output_folder, os.path.splitext(file_name)[0] + '.mp3')

    # 使用edge-tts生成MP3文件
    tts = edge_tts.Communicate(text=text, voice=voice, rate=rate, volume=volume)
    await tts.save(output_path)

if __name__ == '__main__':

    input_folder = 'text'  # 存放txt文件的文件夹（相对路径）
    output_folder = 'output'  # 存放MP3文件的文件夹（相对路径）

    voice = edge_tts_list[1]
    rate = '-4%'
    volume = '+0%'

    # 如果输出文件夹不存在，创建它
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    txt_files = [filename for filename in os.listdir(input_folder) if filename.endswith('.txt')]

    # 使用tqdm创建进度条，遍历txt文件夹中的所有txt文件并处理
    for filename in tqdm(txt_files, desc="处理中"):
        file_path = os.path.join(input_folder, filename)
        asyncio.run(process_text_file(file_path, output_folder))

    print("处理完成！生成的MP3文件保存在output文件夹中。")