import openai
import json
import os
import edge_tts
import asyncio
import py.data_pandas

import pygame
from tqdm import tqdm


def analyse():
    os.environ["HTTP_PROXY"] = "http://127.0.0.1:7890"
    os.environ["HTTPS_PROXY"] = "http://127.0.0.1:7890"

    async def process_text_file(file_path, output_folder):
        # 读取txt文件的内容
        with open(file_path, 'rb') as f:
            data = f.read()
            text = data.decode('utf-8')

        # 创建输出文件名
        file_name = os.path.basename(file_path)
        output_path = os.path.join(output_folder, os.path.splitext(file_name)[0] + '.mp3')

        # 使用edge-tts生成MP3文件
        tts = edge_tts.Communicate(text=text, voice=voice, rate=rate, volume=volume)
        await tts.save(output_path)

    openai.api_key = "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"

    with open("cleaned_data_1.json", encoding="utf-8", mode="r") as f:
        file = json.load(f)
    ls = file["data"][-1]
    print(ls)
    content = {"日期": ls["日期"], "时间": ls["时间"], "经度": ls["经度"], "纬度": ls["纬度"], "高度角": ls["高度角"], "水平辐照": ls["水平辐照"],
               "晴空因子": ls["晴空因子"], "温度": ls["温度"], "湿度": ls["湿度"], "直射辐照": ls["直射辐照"], "散射辐照": ls["散射辐照"]}
    completion = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "你是一个专业的数据分析师"},
            {"role": "user",
             "content": f"我会提供给你一批能够影响太阳直射辐照和散射辐照的数据，请你结合这些数据对应当时的环境，天气和太阳照射进行分析,我现在提供是数据如下{content}，请你按照我的要求进行分析"}
        ]
    )

    # 获取GPT-3.5的回复内容
    gpt_response = completion.choices[0].message["content"]

    # 保存回复内容到文件
    with open("py/text/gpt_answer.txt", "w", encoding="utf-8") as gpt_file:
        gpt_file.write(gpt_response)

    # 打印回复内容
    print("GPT-3.5回复内容已保存到gpt_answer.txt文件中。")

    input_folder = 'py/text'  # 存放txt文件的文件夹（相对路径）
    output_folder = 'static/output'  # 存放MP3文件的文件夹（相对路径）
    edge_tts_list = ['zh-CN-XiaoxiaoNeural', 'zh-CN-XiaoyiNeural', 'zh-CN-YunjianNeural', 'zh-CN-YunxiNeural',
                     'zh-CN-YunxiaNeural', 'zh-CN-YunyangNeural', 'zh-CN-liaoning-XiaobeiNeural',
                     'zh-CN-shaanxi-XiaoniNeural']
    voice = edge_tts_list[1]
    rate = '-4%'
    volume = '+0%'

    # 如果输出文件夹不存在，创建它
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    txt_files = [filename for filename in os.listdir(input_folder) if filename.endswith('.txt')]

    # 使用tqdm创建进度条，遍历txt文件夹中的所有txt文件并处理
    for filename in tqdm(txt_files, desc="处理中"):
        file_path = os.path.join(input_folder, filename)
        asyncio.run(process_text_file(file_path, output_folder))

    print("处理完成！生成的MP3文件保存在output文件夹中。")
    print(gpt_response)
    # 初始化Pygame
    pygame.init()

    # 播放生成的MP3文件
    mp3_file_path = 'static/output/gpt_answer.mp3'  # 替换成生成的MP3文件路径

    try:
        pygame.mixer.music.load(mp3_file_path)
        pygame.mixer.music.play()
        # 等待音频播放完成
        while pygame.mixer.music.get_busy():
            pygame.time.Clock().tick(10)

    except pygame.error:
        print("无法播放音频文件。")
    # 退出Pygame
    pygame.quit()
    py.data_pandas.main()
    return gpt_response


