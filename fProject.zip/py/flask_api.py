from flask import Flask, request
import torch
from torch import nn

app = Flask(__name__)


class NeuralNetwork(nn.Module):
    def __init__(self, dropout_prob=0.45, weight_decay=1e-5):
        super(NeuralNetwork, self).__init__()
        self.fc1 = nn.Linear(7, 128)  # 输入特征维度为 7，输出维度为 128
        self.fc2 = nn.Linear(128, 64)  # 隐藏层1维度为 64
        #self.fc3 = nn.Linear(64, 64)  # 隐藏层2维度为 64
        self.fc4 = nn.Linear(64, 2)  # 输出维度为 2
        self.dropout = nn.Dropout(p=dropout_prob)  # 添加 dropout 层
        self.tanh = nn.Tanh()
        self.relu = nn.LeakyReLU()
        self.sig = nn.Sigmoid()
        self.l2_reg = weight_decay  # L2 正则化的权重衰减系数

    def forward(self, x):
        x = self.tanh(self.fc1(x))
        x = self.relu(self.fc2(x))
        x = self.dropout(x)
        #x = self.relu(self.fc3(x))
        x = self.sig(self.fc4(x))  # 输出层不应使用激活函数
        #x = self.fc4(x)  # 输出层不应使用激活函数
        return x


# 加载神经网络模型
best_model_path = './best_model.pth'
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = NeuralNetwork().to(device=device)  # 请替换为你加载的模型
model.load_state_dict(torch.load(best_model_path))

def my_test(model, input_data):
    model.eval()

    # 将输入数据转换为张量
    input_tensor = torch.tensor(input_data, dtype=torch.float32).to(device)

    # 使用神经网络进行预测
    with torch.no_grad():
        prediction = model(input_tensor)
        prediction[0] *= 500
        prediction[1] *= 800

    return prediction

@app.route('/predict', methods=['POST'])
def predict():
    # 获取GET请求参数，这里假设参数名为data，包含7个数据，以逗号分隔
    input_data = request.args.get('data').split(',')
    input_data = [float(x) for x in input_data]

    # 调用my_test函数进行预测
    prediction = my_test(model, input_data)
    print(prediction)


    # 将预测结果写入txt文件，以空格为间隔
    with open('prediction.txt', 'w') as file:
        file.write(f'{prediction[0]:.2f} {prediction[1]:.2f}')

    return 'Prediction saved to prediction.txt'

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8079)
