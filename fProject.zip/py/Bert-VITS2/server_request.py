import requests

# 服务器地址和端口
server_url = "http://127.0.0.1:5000"

# 输入文本和其他参数
text = input("请输入你想说的话")
speaker = "huan"
sdp_ratio = 0.2
noise_scale = 0.6
noise_scale_w = 0.8
length_scale = 1.0

# 构建GET请求参数
params = {
    "text": text,
    "speaker": speaker,
    "sdp_ratio": sdp_ratio,
    "noise_scale": noise_scale,
    "noise_scale_w": noise_scale_w,
    "length_scale": length_scale,
}

# 发送GET请求
response = requests.get(f"{server_url}/synthesize", params=params)

# 解析响应
if response.status_code == 200:
    data = response.json()
    if "audio_path" in data:
        audio_path = data["audio_path"]
        print(f"生成的音频已保存在: {audio_path}")
    else:
        print("无法找到音频文件路径。")
else:
    print("请求失败，状态码:", response.status_code)
    print("响应内容:", response.text)
