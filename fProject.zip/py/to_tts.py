import os

import requests
import pygame
import py.chatbot

# 服务器地址和端口
server_url = "http://127.0.0.1:5005"
os.environ["HTTP_PROXY"] = "http://127.0.0.1:7890"
os.environ["HTTPS_PROXY"] = "http://127.0.0.1:7890"

def main(text):
    #text = py.chatbot.text_speak()
    #text = py.chatbot.voice_speak()
    speaker = "huan"
    sdp_ratio = 0.2
    noise_scale = 0.6
    noise_scale_w = 0.8
    length_scale = 1.0

    # 构建GET请求参数
    params = {
        "text": text,
        "speaker": speaker,
        "sdp_ratio": sdp_ratio,
        "noise_scale": noise_scale,
        "noise_scale_w": noise_scale_w,
        "length_scale": length_scale,
    }

    # 发送GET请求
    response = requests.get(f"{server_url}/synthesize", params=params)

    # 解析响应
    if response.status_code == 200:
        data = response.json()
        if "audio_path" in data:
            audio_path = data["audio_path"]
            print(f"生成的音频已保存在: {audio_path}")
            # 初始化Pygame
            pygame.init()

            # 播放生成的MP3文件
            mp3_file_path = r"static/output/gpt_answer1.mp3"  # 替换成生成的MP3文件路径

            try:
                pygame.mixer.music.load(mp3_file_path)
                pygame.mixer.music.play()

                # 等待音频播放完成
                while pygame.mixer.music.get_busy():
                    pygame.time.Clock().tick(10)

            except pygame.error:
                print("无法播放音频文件。")

            # 退出Pygame
            pygame.quit()
        else:
            print("无法找到音频文件路径。")
    else:
        print("请求失败，状态码:", response.status_code)
        print("响应内容:", response.text)
