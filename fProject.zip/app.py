import json
import os

from py import gptapi
from flask import Flask, request, jsonify
from flask import render_template
import pymysql
import py.chatbot
import py.to_tts
from predict import NeuralNetwork, my_test
from datetime import datetime
# from trainer import test_model
import mysql.connector
from mysql.connector import errorcode

os.environ["HTTP_PROXY"] = "http://127.0.0.1:7890"
os.environ["HTTPS_PROXY"] = "http://127.0.0.1:7890"
app = Flask(__name__)
save_data = []


def create_user(account, password):
    try:
        # 数据库连接配置
        dbcongig = pymysql.connect(
            host="localhost",
            port=3306,
            user="root",
            password="123456",
            database="user"
        )
        cursor = dbcongig.cursor()

        # 检查用户名是否已存在
        check_query = "SELECT * FROM myuser WHERE account = %s"
        cursor.execute(check_query, [account])
        existing_user = cursor.fetchone()
        if existing_user:
            cursor.close()
            dbcongig.close()
            return "existence"  # 帐户已存在，注册失败

        # 插入新用户
        insert_query = "INSERT INTO myuser VALUES (%s, %s)"
        user_data = [account, password]
        cursor.execute(insert_query, user_data)

        dbcongig.commit()
        cursor.close()
        dbcongig.close()
        return "success"
    except pymysql.connect.Error as err:
        if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
            return "failure"
        elif err.errno == errorcode.ER_BAD_DB_ERROR:
            return "failure"
        else:
            return "failure"


def authenticate_user(account, password):
    try:
        # 数据库连接配置
        dbcongig = pymysql.connect(
            host="localhost",
            port=3306,
            user="root",
            password="123456",
            database="user"
        )
        cursor = dbcongig.cursor()
        query = "select * from myuser where account = %s and password = %s"
        cursor.execute(query, [account, password])
        user = cursor.fetchone()
        # user = cursor.fetchall()  #查询多条结果
        cursor.close()
        dbcongig.close()

        if user:
            return "success"
        else:
            return "failure"
    except pymysql.connect.Error as err:
        return "failure"


def save_predict(save_data):
    try:
        # 数据库连接配置
        dbcongig = pymysql.connect(
            host="localhost",
            port=3306,
            user="root",
            password="123456",
            database="user"
        )
        cursor = dbcongig.cursor()

        # 插入新用户
        insert_query = "INSERT INTO predictdata VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
        cursor.execute(insert_query, save_data)

        dbcongig.commit()
        cursor.close()
        dbcongig.close()
        return "success"
    except pymysql.connect.Error as err:
        if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
            return "failure"
        elif err.errno == errorcode.ER_BAD_DB_ERROR:
            return "failure"
        else:
            return "failure"


@app.route('/')
def maininterface():  # put application's code here
    return render_template("newmain.html")


# 处理注册请求
@app.route('/register', methods=['POST'])
def register():
    data = request.form
    account = data['account']
    password = data['password']
    print(data)

    result = create_user(account, password)
    return result


# 处理登录请求
@app.route('/login', methods=['POST'])
def login():
    data = request.form
    account = data['account']
    password = data['password']

    result = authenticate_user(account, password)
    return result


@app.route('/predict', methods=['GET', 'POST'])
def predict():
    return render_template("predict.html")


@app.route('/enroll')
def enroll():
    return render_template("newregister.html")


@app.route('/analyse', methods=['GET', 'POST'])
def analyse():
    return render_template("analyse.html")

@app.route('/aianalyse', methods=['POST'])
def aianalyse():
    content = gptapi.analyse()
    response_data = {'messages': content}
    # 返回响应数据
    #print(response_data)
    return jsonify(response_data)


@app.route('/aimessageanalyse', methods=['POST'])
def aimessageanalyse():
    data = request.json
    print(data)
    # content = gptapi.analyse()
    content = py.chatbot.chat(data)
    py.to_tts.main(content)
    response_data = {'messages': content}
    # 返回响应数据
    #print(response_data)
    return jsonify(response_data)

@app.route('/datapredict', methods=['POST'])
def datapredict():
    data = request.form
    global save_data
    predict_data = []
    print(data)
    label = ["longitude", "latitude", "altitude", "azimuth", "azimuthangle", "horizontalirradiation", "clearnessindex",
             "temperature", "humidity"]
    for m in label:
        if m != "azimuth" and m != "azimuthangle":
            m = data[m]
            predict_data.append(m)

    # 获取当前日期时间
    current_datetime = datetime.now()

    # 格式化日期为 "年-月-日" 形式
    formatted_date = current_datetime.strftime("%Y-%m-%d")

    # 格式化时间为 "时:分" 形式
    formatted_time = current_datetime.strftime("%H:%M")

    save_data.append(formatted_date)
    save_data.append(formatted_time)

    for n in label:
        n = data[n]
        save_data.append(n)

    # 调用my_test函数进行预测
    prediction = my_test(predict_data)

    for i in range(len(prediction)):
        save_data.append(str(round(prediction[i].item(), 2)))
    save_data.append('98.47%')
    #os.remove("static/output/gpt_answer.mp3")
    # print(save_data)
    with open("cleaned_data.json", encoding="utf-8", mode="r") as f:
        file = json.load(f)
    content = {"日期": save_data[0], "时间": save_data[1], "经度": save_data[2], "纬度": save_data[3], "高度角": save_data[4],
               "方位角": save_data[5], "转角": save_data[6],
               "水平辐照": save_data[7], "晴空因子": save_data[8], "温度": save_data[9], "湿度": save_data[10],
               "直射辐照": save_data[11], "散射辐照": save_data[12]}
    file["data"].append(content)
    with open("cleaned_data_1.json", encoding="utf-8", mode="w") as f:
        json.dump(file, f)

    if len(save_data) == 14:
        # 将预测结果作为JSON响应返回给前端
        return jsonify(
            {'directirradiation': save_data[-3], 'scatteredirradiation': save_data[-2], 'confident': save_data[-1]})
    else:
        return "failure"


@app.route('/save', methods=['POST'])
def save():
    global save_data
    if len(save_data) != 14:
        return "wrong"
    else:
        result = save_predict(save_data)
        save_data = []
        return "success"


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5001, debug=True)
